package com.niit.backend.implementation;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.niit.backend.dao.BlogDao;
import com.niit.backend.model.Blog;
import com.niit.backend.model.Event;

@Repository
public class BlogDaoImpl implements BlogDao {
	@Autowired
	private SessionFactory sessionFactory;

	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	public String currentDateYYYYMMDD() {
		/*
		 * SimpleDateFormat sdfDate = new
		 * SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//dd/MM/yyyy Date now = new
		 * Date(); String strDate = sdfDate.format(now); return strDate;
		 */

		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
		Date date = new Date();
		String strDate = dateFormat.format(date);
		return strDate;
	}

	public String currentTimeHHmmss() {
		DateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
		Date date = new Date();
		String strTime = dateFormat.format(date);
		return strTime;
	}

	public void createBlog(Blog blog) {
		blog.setCreateddate(currentDateYYYYMMDD());
		Session session = sessionFactory.openSession();
		session.save(blog);
		session.flush();
		session.close();
	}

	public List<Blog> getAllBlogs(String role) {
		Session session = sessionFactory.openSession();
		Query query;
		if (role.equals("Admin"))
			query = session.createQuery("from Blog order by blogid desc");
		else
			query = session
					.createQuery("from Blog where status= 'A' order by blogid desc");
		List<Blog> blogs = query.list();
		session.close();
		return blogs;
	}

	public List<Blog> getAllBlogName() {
		Session session = sessionFactory.openSession();
		// Query query =
		// session.createQuery("select  Blog where( status )='approved'  order by blogid desc");
		Query query = session
				.createQuery("select Blogname from Blog order by blogid desc");
		List<Blog> blogs = query.list();
		session.close();
		return blogs;
	}
	
public Blog getBlogById(int id) {
		Session session = sessionFactory.openSession();
		// select * from personinfo where id=2
		Query qry = session.createQuery("from Blog where blogid=" + id);
		Blog blog = (Blog) qry.uniqueResult();
		// Blog blog = (Blog) session.get(Blog.class, id);
		System.out
				.println("Backend BlogDaoImpl..................................");
		System.out.println(blog.getBlogid());
		System.out.println(blog.getBlogDescription());
		System.out.println(blog.getBlogname());
		session.close();
		return blog;

	}

	@Transactional
	public Blog bloglikes(int blogid) {
		Session session = sessionFactory.openSession();
		Query query = session
				.createQuery("update Blog set bloglikes = bloglikes+1 where blogid = "
						+ blogid);
		query.executeUpdate();
		Blog updatedBlog = (Blog) session.get(Blog.class, blogid); // select
		session.flush();
		session.close();
		return updatedBlog;
	}

	/*
	 * @Transactional public Blog bloglikes(int blogid, Blog blog) { Session
	 * session = sessionFactory.openSession();
	 * System.out.println("Id of Blog is to update is: " + blog.getBlogid()); if
	 * (session.get(Blog.class, blogid) == null) return null;
	 * session.merge(blog); // update query where personid=? // select [after
	 * modification] Blog updatedBlog = (Blog) session.get(Blog.class, blogid);
	 * // select query session.flush(); session.close(); return updatedBlog; }
	 */

	@Transactional
	public Blog blogdislikes(int blogid) {
		Session session = sessionFactory.openSession();
		Query query = session
				.createQuery("update Blog set blogdislikes = blogdislikes+1 where blogid = "
						+ blogid);
		query.executeUpdate();
		Blog updatedBlog = (Blog) session.get(Blog.class, blogid); // select
		session.flush();
		session.close();
		return updatedBlog;
	}

	@Transactional
	public Blog updateBlog(int blogid, Blog blog) {
		Session session = sessionFactory.openSession();
		System.out.println("Id of Blog is to update is: " + blogid);
		if (session.get(Blog.class, blogid) == null)
			return null;
		session.merge(blog); // update query where personid=?
		// select [after modification]
		Blog updatedBlog = (Blog) session.get(Blog.class, blogid); // select
																	// query
		session.flush();
		session.close();
		return updatedBlog;

	}

	@Transactional
	public void deleteBlog(int blogid) {
		Session session = sessionFactory.openSession();

		Blog blog = (Blog) session.get(Blog.class, blogid);
		session.delete(blog);

		session.flush();
		session.close();

	}

	public List<Blog> getBlogByStatus(String status) {
		Session session = sessionFactory.openSession();
		Query query = session.createQuery("from Blog where status ='" + status
				+ "' order by blogid desc");
		List<Blog> blogs = query.list();
		session.close();
		return blogs;
	}

}
