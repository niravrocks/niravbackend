app.controller('JobController', function($scope, $rootScope, $location,
		JobService) {
	$scope.jobs;
	$scope.job = {
		jobId : '',
		jobTitle : '',
		jobDescription : '',
		postedon : '',
		skillsRequired : '',
		salary : '',
		location : '',
		status : '',
		hasexpired : '',
		validity : ''
	}
	

	$scope.showJobDetail = false
	$scope.saveJob = function() {
		console.log('entering save job in job controller')
		$scope.myerror=JobService.saveJob($scope.job).then(function(response) {
			if (response.status==200)
				{
	console.log("successfully inserted job details" + response.status);
			alert("Posted job successfully");
			$location.path('/home');
				}
		}, function(response) {
			console.log("failure " + response.status);
			if (response.status == 401) {
				$location.path('/login')
			} 		
			else {
				console.log(response.data.message)
				alert("Pls. enter valid data..")
				$location.path('/postJob')
			}
		})
	}

	function fetchAllJobs() {
		console.log('entering fetchall jobs in job controller')
		JobService.fetchAllJobs().then(function(d) {
			$scope.jobs = d;
		}, function(error) {
			console.log(error);
		})
	}
	fetchAllJobs();
	
	
	function getAllTitle() {
		console.log('entering get all jobs title')
		JobService.getAllTitle().then(function(response) {
			console.log(response.status);
			$scope.title = response.data;
		}, function(response) {
			console.log(response.status)
		})

	}
	getAllTitle();

	
	
	
	

	$scope.getJobDetail = function(jobId) {
		$scope.showJobDetail = true;
		JobService.getJobDetail(jobId).then(function(response) {
			$scope.jobDetail = response.data; // single Job object
			console.log(response.status)

		}, function(response) {
			console.log(response.status)
		})

	}
	
	/*
	 * function getAllJobs() { console.log('entering get all jobs')
	 * JobService.getAllJobs().then(function(response) {
	 * console.log(response.status); $scope.jobs = response.data;
	 *  }, function(response) { console.log(response.status) })
	 *  } getAllJobs();
	 */

	$scope.deleteJob = function(id) {
		console.log("entering delete user in controller with id " + id)
		JobService.deleteJob(id).then(function(d) {
			console.log('deleted successfully')
			console.log(d)
			fetchAllJobs();
			$location.path('/listJobs')
		}, function() {
			console.log("unable to delete the record")
		})

	}
})
